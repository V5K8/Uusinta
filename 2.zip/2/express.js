const express = require("express");
const app = express();
const port = process.env.PORT || 8080;
const { readCart, createCart } = require("./filename");

app.use(express.json());

app.get("/shopping-cart", async (req, res) => {
  res.json({ data: await readCart() });
});

app.get("/shopping-cart/:searchTerm", async (req, res) => {
  const id = req.params.searchTerm;
  res.json({ data: await readCart(id) });
});

app.post("/shopping-cart", async (req, res) => {
  res.json(await createCart(req.body));
});

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});
